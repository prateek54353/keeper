import 'dart:async';
import 'package:flutter/material.dart';
import 'package:keeper/services/firestore_service.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:keeper/providers/settings_provider.dart';
import 'package:flutter_markdown/flutter_markdown.dart';

class NoteEditorScreen extends StatefulWidget {
  final FirestoreService firestoreService;
  final String? docID;
  final String? title;
  final String? content;
  final bool? isLocked;

  const NoteEditorScreen({
    super.key,
    required this.firestoreService,
    this.docID,
    this.title,
    this.content,
    this.isLocked,
  });

  @override
  State<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends State<NoteEditorScreen> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _contentController = TextEditingController();
  Timer? _debounce;
  bool _isNewNote = true;
  bool _isPreviewMode = false;
  late bool _isLocked;

  @override
  void initState() {
    super.initState();
    _titleController.text = widget.title ?? '';
    _contentController.text = widget.content ?? '';
    _isNewNote = widget.docID == null;
    _isLocked = widget.isLocked ?? false;
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  void _saveNote() {
    if (_titleController.text.isNotEmpty || _contentController.text.isNotEmpty) {
      if (_isNewNote) {
        widget.firestoreService.addNote(
          _titleController.text,
          _contentController.text,
          isLocked: _isLocked,
        );
        _isNewNote = false;
      } else {
        widget.firestoreService.updateNote(
          widget.docID!,
          _titleController.text,
          _contentController.text,
          isLocked: _isLocked,
        );
      }
    }
  }

  void _onTextChanged() {
    if (_debounce?.isActive ?? false) _debounce!.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () {
      _saveNote();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settings, child) {
        return Scaffold(
          appBar: AppBar(
            title: Hero(
              tag: 'note_title_${widget.docID ?? "new"}',
              child: Material(
                color: Colors.transparent,
                child: _isPreviewMode
                    ? Text(
                        _titleController.text,
                        style: GoogleFonts.getFont(settings.fontFamily).copyWith(
                          fontSize: Theme.of(context).textTheme.titleLarge?.fontSize,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      )
                    : TextField(
                        controller: _titleController,
                        style: GoogleFonts.getFont(settings.fontFamily).copyWith(
                          fontSize: Theme.of(context).textTheme.titleLarge?.fontSize,
                        ),
                        decoration: const InputDecoration(
                          hintText: 'Title',
                          border: InputBorder.none,
                        ),
                        onChanged: (_) => _onTextChanged(),
                      ),
              ),
            ),
            actions: [
              IconButton(
                icon: Icon(_isPreviewMode ? Icons.edit : Icons.remove_red_eye),
                onPressed: () {
                  setState(() {
                    _isPreviewMode = !_isPreviewMode;
                  });
                },
              ),
              Padding(
                padding: const EdgeInsets.only(right: 8.0),
                child: Tooltip(
                  message: _isLocked ? 'Unlock Note' : 'Lock Note',
                  child: Switch(
                    value: _isLocked,
                    onChanged: (bool value) {
                      setState(() {
                        _isLocked = value;
                      });
                      _saveNote();
                    },
                  ),
                ),
              ),
            ],
          ),
          body: _isPreviewMode
              ? Markdown(data: _contentController.text)
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextField(
                        controller: _contentController,
                        maxLines: null,
                        decoration: const InputDecoration(
                          hintText: 'Start writing...',
                          border: InputBorder.none,
                        ),
                        style: GoogleFonts.getFont(settings.fontFamily).copyWith(
                          fontSize: settings.fontSize,
                        ),
                        onChanged: (_) => _onTextChanged(),
                      ),
                    ],
                  ),
                ),
        );
      },
    );
  }
} 